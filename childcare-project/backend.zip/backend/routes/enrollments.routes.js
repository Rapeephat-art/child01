// backend/routes/enrollments.routes.js
const express = require('express');
const router = express.Router();
const pool = require('../db.js'); // mysql2 promise pool
const multer = require('multer');
const path = require('path');
const fs = require('fs');

// upload config (เก็บใน uploads/enrollments)
const UPLOAD_DIR = process.env.UPLOAD_DIR || path.join(__dirname, '..', 'uploads', 'enrollments');
if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, UPLOAD_DIR);
  },
  filename: function (req, file, cb) {
    const ext = path.extname(file.originalname);
    const base = path.basename(file.originalname, ext).replace(/\s+/g, '_');
    cb(null, `${Date.now()}_${base}${ext}`);
  }
});
const upload = multer({ storage });

// -------------------------------
// GET /api/enrollments  — list (latest first)
// -------------------------------
router.get('/', async (req, res) => {
  try {
    // ปรับ SELECT ตาม schema จริงของคุณ ถ้าต้องการ payload ด้วย ให้เพิ่มคอลัมน์ payload
    const [rows] = await pool.query(
      'SELECT enrollment_id, parent_id, status, created_at FROM enrollments ORDER BY created_at DESC LIMIT 500'
    );
    res.json({ ok: true, rows });
  } catch (err) {
    console.error('enrollments.list err', err);
    res.status(500).json({ ok: false, error: 'cannot list enrollments' });
  }
});

// -------------------------------
// POST /api/enrollments/draft
// body: arbitrary JSON form payload
// -------------------------------
router.post('/draft', async (req, res) => {
  try {
    const parentId = req.body.parent_id || null; // optional
    const payload = JSON.stringify(req.body);
    const status = 'draft';
    const [result] = await pool.query(
      'INSERT INTO enrollments (parent_id, payload, status, created_at, updated_at) VALUES (?, ?, ?, NOW(), NOW())',
      [parentId, payload, status]
    );
    const draftId = result.insertId;
    res.json({ ok: true, draftId });
  } catch (err) {
    console.error('enrollments.draft err', err);
    res.status(500).json({ ok: false, error: 'cannot save draft' });
  }
});

// -------------------------------
// GET /api/enrollments/:id
// -------------------------------
router.get('/:id', async (req, res) => {
  try {
    const id = req.params.id;
    const [rows] = await pool.query('SELECT * FROM enrollments WHERE enrollment_id = ?', [id]);
    if (rows.length === 0) return res.status(404).json({ ok: false, error: 'not found' });
    const row = rows[0];
    // parse payload if present
    let payload = null;
    try { payload = row.payload ? JSON.parse(row.payload) : null; } catch(e){ payload = row.payload; }
    res.json({ ok: true, enrollment: { ...row, payload } });
  } catch (err) {
    console.error('enrollments.get err', err);
    res.status(500).json({ ok: false, error: 'cannot read' });
  }
});

// -------------------------------
// POST /api/enrollments  (final submit) - expecting multipart/form-data
// fields: payload text fields and files
// -------------------------------
const fileFields = [
  { name: 'attachment_birth_certificate', maxCount: 1 },
  { name: 'attachment_reg_child', maxCount: 1 },
  { name: 'attachment_father_id', maxCount: 1 },
  { name: 'attachment_father_reg', maxCount: 1 },
  { name: 'attachment_mother_id', maxCount: 1 },
  { name: 'attachment_mother_reg', maxCount: 1 }
];

router.post('/', upload.fields(fileFields), async (req, res) => {
  try {
    // payload: fields may include many keys (we'll collect all non-file fields)
    // note: if client sent a single "payload" JSON field, prefer that
    let payloadObj = {};
    if (req.body.payload) {
      try { payloadObj = JSON.parse(req.body.payload); } catch(e){ payloadObj = { payload: req.body.payload }; }
    } else {
      // copy all text fields
      Object.keys(req.body).forEach(k => payloadObj[k] = req.body[k]);
    }

    // attach uploaded file paths (relative)
    if (req.files) {
      for (const [field, files] of Object.entries(req.files)) {
        if (files && files[0]) {
          payloadObj[field] = files[0].filename; // store filename
        }
      }
    }

    const parentId = payloadObj.parent_id || null;
    const status = 'submitted';
    const payloadStr = JSON.stringify(payloadObj);

    const [result] = await pool.query(
      'INSERT INTO enrollments (parent_id, payload, status, created_at, updated_at) VALUES (?, ?, ?, NOW(), NOW())',
      [parentId, payloadStr, status]
    );

    res.json({ ok: true, enrollmentId: result.insertId });
  } catch (err) {
    console.error('enrollments.create err', err);
    res.status(500).json({ ok: false, error: 'cannot create enrollment' });
  }
});

// (optional) PUT /api/enrollments/:id  — update enrollment (basic)
router.put('/:id', async (req, res) => {
  try {
    const id = req.params.id;
    // assume client sends full payload object in body
    const payloadStr = JSON.stringify(req.body.payload || req.body);
    await pool.query('UPDATE enrollments SET payload = ?, updated_at = NOW() WHERE enrollment_id = ?', [payloadStr, id]);
    res.json({ ok: true });
  } catch (err) {
    console.error('enrollments.update err', err);
    res.status(500).json({ ok: false, error: 'cannot update enrollment' });
  }
});

// (optional) DELETE /api/enrollments/:id
router.delete('/:id', async (req, res) => {
  try {
    const id = req.params.id;
    await pool.query('DELETE FROM enrollments WHERE enrollment_id = ?', [id]);
    res.json({ ok: true });
  } catch (err) {
    console.error('enrollments.delete err', err);
    res.status(500).json({ ok: false, error: 'cannot delete enrollment' });
  }
});

module.exports = router;
